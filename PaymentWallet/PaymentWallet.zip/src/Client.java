public class Client
{
	public String [] menu = {"Create Account", "Show Balance", "Deposit", "Fund Trasnfer", "Print Transactions"};
	
	public void run ()
	{
		
	}
	
	public static void main (String [] args)
    {
	    new Client ().run ();
    }
}